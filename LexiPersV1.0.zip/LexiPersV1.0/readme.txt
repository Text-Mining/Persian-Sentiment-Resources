﻿مجموعه صفات دارای برچسب قطبیت (لکسی پرس)
LexiPers: An ontology based sentiment lexicon for Persian

مالکیت معنوی: آزمایشگاه پردازش زبان طبیعی دانشگاه صنعتی شریف و گروه پردازش زبان طبیعی دانشگاه گیلان

استفاده از این پیکره با ذکر منبع و برای هرگونه فعالیتی اعم از پژوهشی یا تجاری بلامانع است.

لطفاً در صورت استفاده از این داده، به صورت زیر به آن ارجاع دهید:

Behnam Sabeti, Pedram Hosseini, Gholamreza Ghassem-Sani, and Seyed Abolghasem Mirroshandel. 2016. Lexipers: An ontology based sentiment lexicon for Persian. In 2nd Global Conference on Artificial Intelligence (GCAI), volume 41, pages 329–339. EasyChair.

@inproceedings{sabeti2016lexipers,
  title={LexiPers: An ontology based sentiment lexicon for Persian},
  author={Sabeti, Behnam and Hosseini, Pedram and Ghassem-Sani, Gholamreza and Mirroshandel, Seyed Abolghasem},
  booktitle={2nd Global Conference on Artificial Intelligence (GCAI)},
  volume={41},
  pages={329--339},
  year={2016},
  organization={EasyChair}
}

- - - - - - - - - - - - - - - - - - - - - - - - 
http://dadegan.ir/catalog/lexipers